package net.ajaskey.market.tools.SIP.BigDB.reports;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import net.ajaskey.market.tools.SIP.SipSectorIndustryRS;
import net.ajaskey.market.tools.SIP.BigDB.dataio.FieldData;
import net.ajaskey.market.tools.SIP.BigDB.dataio.Options;
import net.ajaskey.market.tools.SIP.BigDB.derived.CompanyDerived;
import net.ajaskey.market.tools.SIP.BigDB.reports.utils.Scans;
import net.ajaskey.market.tools.SIP.BigDB.reports.utils.Utilities;

public class WriteOptumaExternal {

  /**
   *
   * @param args
   * @throws FileNotFoundException
   */
  public static void main(String[] args) throws FileNotFoundException {

    System.out.println("WriteOptumaExternal...");

    /**
     * Process Sector and Industry Relative Strength
     */
    SipSectorIndustryRS ssi = new SipSectorIndustryRS("From WriteOptumaExternal", true);

    int year = 2022;
    int quarter = 3;

    Options.readOptionData(year, quarter);

    List<CompanyDerived> dRList = Scans.findMajor(year, quarter, 2.0, 5000L);

    try (PrintWriter pw = new PrintWriter("D:/dev/MarketTools - dev/lists/OptumaExternalData.csv");
        PrintWriter pwCode = new PrintWriter("D:/dev/MarketTools - dev/lists/OptumaExternalCodes.csv")) {

      pw.printf("Code, CityExt, StateExt, CountryExt, SectorExt, IndustryExt, OptionableExt, NavExt, SectorRsExt, IndustryRsExt,");
      pw.printf("FloatExt, MktCapExt %n");

      pwCode.println("Code");

      for (final CompanyDerived cdr : dRList) {
        print(pw, cdr);
        pwCode.println(cdr.getTicker());
      }

      // Add important not found by scan
      CompanyDerived brkb = Scans.findCompany(year, quarter, "BRK.B");
      print(pw, brkb);

      printExtras(pw, "GASS", "ERITHREA", "ATHINA", "Greece", "Industrials", "Freight & Logistics - Marine");
      printExtras(pw, "CCO", "SAN ANTONIO", "TX", "United States", "Consumer Cyclicals", "Advertising & Marketing");
      printExtras(pw, "Z", "SEATTLE", "WA", "United States", "Real Estate", "Real Estate Services");

      printExtras(pw, "XLB", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLE", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLF", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLI", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLK", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLP", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLU", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLV", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLY", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLC", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XLRE", "", "", "United States", "Financials", "ETF");

      printExtras(pw, "SPY", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "QQQ", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "DIA", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XHB", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "VNQ", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "TLT", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "IWM", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "XRT", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "KRE", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "KIE", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "IGV", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "SMH", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "IBB", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "BOTZ", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "SLV", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "JNK", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EWT", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "INDA", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EWJ", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EWQ", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EFA", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EWI", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EWY", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EWZ", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "EEM", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "FXI", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "HYG", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "JNK", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "MBB", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "PICK", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "WOOD", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "TAN", "", "", "United States", "Financials", "ETF");
      printExtras(pw, "JETS", "", "", "United States", "Financials", "ETF");
    }

    System.out.println("Done.");
  }

  private static void printExtras(PrintWriter pw, String code, String city, String state, String country, String sector, String industry) {
    printcol(pw, code);
    printcol(pw, city);
    printcol(pw, state);
    printcol(pw, country);
    printcol(pw, sector);
    printcol(pw, industry);
    pw.println("1, 0, 0, 0, 0, 0");
  }

  private static void print(PrintWriter pw, CompanyDerived cdr) {
    try {
      FieldData fd = cdr.getFd();
      if (fd.getShareData().getFloatshr() > 0.05) {
        printcol(pw, fd.getTicker());
        printcol(pw, fd.getCompanyInfo().getCity());
        printcol(pw, fd.getCompanyInfo().getState());
        printcol(pw, fd.getCompanyInfo().getCountry());
        String sec = Utilities.cleanSecInd(fd.getCompanyInfo().getSector());
        String ind = Utilities.cleanSecInd(fd.getCompanyInfo().getIndustry());
        printcol(pw, sec);
        printcol(pw, ind);
        if (Options.isOptionable(fd.getTicker())) {
          printcol(pw, 1);
        }
        else {
          printcol(pw, 0);
        }
        Double navps = cdr.getNetNavps();
        printcol(pw, Math.max(navps, 0));

        double srs = SipSectorIndustryRS.getSectorRS(sec);
        double irs = SipSectorIndustryRS.getIndustryRS(ind);

        printcol(pw, srs);
        printcol(pw, irs);

        double tmp;
        tmp = fd.getShareData().getFloatshr();
        printcol(pw, tmp);

        tmp = fd.getShareData().getMktCap();
        printcol(pw, tmp);

        pw.println("");
      }
    }
    catch (Exception e) {
    }
  }

  private static void printcol(PrintWriter pw, double d) {
    pw.printf("%f,", d);
  }

  private static void printcol(PrintWriter pw, int i) {
    pw.printf("%d,", i);
  }

  private static void printcol(PrintWriter pw, String str) {
    pw.printf("%s,", str.replace(",", ";").trim());
  }

}
