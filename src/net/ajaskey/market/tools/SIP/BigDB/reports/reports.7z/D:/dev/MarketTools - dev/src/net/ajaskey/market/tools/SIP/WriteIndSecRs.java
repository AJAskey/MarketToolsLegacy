package net.ajaskey.market.tools.SIP;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.ajaskey.common.TextUtils;
import net.ajaskey.common.Utils;
import net.ajaskey.market.tools.SIP.BigDB.reports.utils.Utilities;

public class WriteIndSecRs {

  public class Fields {
    String code;
    String industry;
    double rs1;
    double rs12;
    double rs3;
    double rs6;
    String sector;
    double weightedRS;

    /**
     * One-third 12m + One-third 6m + 0.255 3m + 0.085 1m
     *
     * @return
     */
    public double calcRS() {
      final double ret = this.rs12 * 0.33 + this.rs6 * 0.33 + this.rs3 * 0.255 + this.rs1 * 0.085;
      return ret;
    }
  }

  public class GroupData {

    String groupName;

    double groupRS;

    List<Fields> list = null;

    /**
     *
     * @param s
     */
    public GroupData(String s) {
      this.groupName = s;
      this.list = new ArrayList<>();
      this.groupRS = 0.0;
    }

    /**
     * Average all in the group
     */
    public void calcGroupRS() {
      double grs = 0.0;
      for (final Fields f : this.list) {
        grs += f.weightedRS;
      }
      this.groupRS = grs / this.list.size();
    }
  }

  static List<GroupData> industryList = new ArrayList<>();

  final static double MAX_RS = 75.0;

  static List<GroupData> sectorList = new ArrayList<>();

  /**
   *
   */
  private static List<Fields>  fieldList = new ArrayList<>();
  /**
   *
   */
  private static WriteIndSecRs wis       = new WriteIndSecRs();

  /**
   *
   * @param args
   * @throws FileNotFoundException
   */
  public static void main(String[] args) throws FileNotFoundException {

    final Set<String> industries = new HashSet<>();
    final Set<String> sectors = new HashSet<>();

    /**
     * Process:
     * 
     * Export SectorIndustry view for all items within SIP.
     * 
     * Execute processSipSectorIndustryData() for format this file - output is in
     * input/CODESECTORINDUSTRY-SIP.csv
     * 
     * Import this list into a Optuma a Watchlist and add CodesWithRS Layout. Export
     * Watchlist to Excel and save as CSV into input directory as RSfromOptuma.csv
     * 
     */
    processSipSectorIndustryData();

    /**
     * Process:
     * 
     * Merge into Sector/Industry/RS file
     * 
     */
    processCalcAndCombined();

    final List<String> data = TextUtils.readTextFile("input/SecIndRS.txt", true);

    /**
     * Read data file and create entry for each company
     */
    int cnt = 0;
    for (final String s : data) {
      cnt++;
      if (cnt > 1) {
        try {
          final Fields fld = WriteIndSecRs.wis.new Fields();

          final String ss[] = s.split("\t");
          fld.code = ss[0];
          // fld.name = ss[1].trim();
          fld.sector = ss[1].trim();
          fld.industry = ss[2].trim();

          if (fld.sector.length() > 0 && fld.industry.length() > 0) {

            double tmp = Utils.parseDouble(ss[3].trim());
            fld.rs1 = Math.min(tmp, WriteIndSecRs.MAX_RS);
            tmp = Utils.parseDouble(ss[4].trim());
            fld.rs3 = Math.min(tmp, WriteIndSecRs.MAX_RS);
            tmp = Utils.parseDouble(ss[5].trim());
            fld.rs6 = Math.min(tmp, WriteIndSecRs.MAX_RS);
            tmp = Utils.parseDouble(ss[6].trim());
            fld.rs12 = Math.min(tmp, WriteIndSecRs.MAX_RS);

            if (Math.abs(fld.rs12) > 0.0) {

              fld.weightedRS = fld.calcRS();

              WriteIndSecRs.fieldList.add(fld);
              sectors.add(fld.sector);
              industries.add(fld.industry);
            }
          }
        }
        catch (final Exception e) {
          System.out.printf("Error input data line : %5d%n", cnt);
        }
      }
    }

    /**
     * Create a list of Sectors
     */
    final List<String> dls = new ArrayList<>(sectors);
    Collections.sort(dls);
    for (final String s : dls) {
      final GroupData gd = WriteIndSecRs.wis.new GroupData(s);
      WriteIndSecRs.sectorList.add(gd);
      System.out.println(s);
    }

    System.out.printf("%n%n%n");

    /**
     * Create a list of Industries
     */
    final List<String> dli = new ArrayList<>(industries);
    Collections.sort(dli);
    for (final String s : dli) {
      final GroupData gd = WriteIndSecRs.wis.new GroupData(s);
      WriteIndSecRs.industryList.add(gd);
      System.out.println(s);
    }

    System.out.printf("%nSectors    : %d%n", WriteIndSecRs.sectorList.size());
    System.out.printf("Industries : %d%n", WriteIndSecRs.industryList.size());

    /**
     * Add Field data to Sector and Industry group lists
     */
    for (final Fields fld : WriteIndSecRs.fieldList) {
      GroupData gd;

      System.out.printf("%nCode               : %s%n", fld.code);

      gd = WriteIndSecRs.getSector(fld.sector);
      gd.list.add(fld);
      System.out.printf("Sector groupName   : %s\t%d%n", gd.groupName, gd.list.size());

      gd = WriteIndSecRs.getIndustry(fld.industry);
      gd.list.add(fld);
      System.out.printf("Industry groupName : %s\t%d%n", gd.groupName, gd.list.size());
    }

    // try (PrintWriter pw = new
    // PrintWriter("D:\\dev\\eclipse-markettools\\MarketTools\\lists\\SectorIndustryRS.csv"))
    // {
    try (PrintWriter pw = new PrintWriter("out/SectorRS.csv")) {
      // pw.println("SectorNameExt, SectorRsExt");
      System.out.printf("%n%n%n");
      for (final GroupData gd : WriteIndSecRs.sectorList) {
        gd.calcGroupRS();
        System.out.printf("Sector groupName   : %s\t%d\t%.2f%n", gd.groupName, gd.list.size(), gd.groupRS);
        pw.printf("%s, %.2f%n", gd.groupName, gd.groupRS);
      }
    }
    System.out.printf("%n%n%n");
    try (PrintWriter pw = new PrintWriter("out/IndustryRS.csv")) {
      // pw.println("IndustyNameExt, IndustryRsExt");
      for (final GroupData gd : WriteIndSecRs.industryList) {
        gd.calcGroupRS();
        System.out.printf("Industry groupName   : %s\t%d\t%.2f%n", gd.groupName, gd.list.size(), gd.groupRS);
        pw.printf("%s, %.2f%n", gd.groupName, gd.groupRS);
      }
    }
  }

  private static void processCalcAndCombined() {
    final List<String> data = TextUtils.readTextFile("input/RSfromOptuma.csv", true);

    /**
     * Read data file and create entry for each company
     */
    int cnt = 0;
    for (final String s : data) {
      cnt++;
      if (cnt > 1) {
        try {
          final Fields fld = WriteIndSecRs.wis.new Fields();

          final String ss[] = s.split("\t");
          fld.code = ss[0];
          // fld.name = ss[1].trim();
          fld.sector = ss[1].trim();
          fld.industry = ss[2].trim();

          if (fld.sector.length() > 0 && fld.industry.length() > 0) {

            double tmp = Utils.parseDouble(ss[3].trim());
            fld.rs1 = Math.min(tmp, WriteIndSecRs.MAX_RS);
            tmp = Utils.parseDouble(ss[4].trim());
            fld.rs3 = Math.min(tmp, WriteIndSecRs.MAX_RS);
            tmp = Utils.parseDouble(ss[5].trim());
            fld.rs6 = Math.min(tmp, WriteIndSecRs.MAX_RS);
            tmp = Utils.parseDouble(ss[6].trim());
            fld.rs12 = Math.min(tmp, WriteIndSecRs.MAX_RS);

            if (Math.abs(fld.rs12) > 0.0) {

              fld.weightedRS = fld.calcRS();

              WriteIndSecRs.fieldList.add(fld);
              // sectors.add(fld.sector);
              // industries.add(fld.industry);
            }
          }
        }
        catch (final Exception e) {
          System.out.printf("Error input data line : %5d%n", cnt);
        }
      }
    }

  }

  private static void processSipSectorIndustryData() {

    final List<String> data = TextUtils.readTextFile("input/CODESECTORINDUSTRY-SIP.TXT", true);

    try (PrintWriter pw = new PrintWriter("input/CODESECTORINDUSTRY.csv")) {
      for (String s : data) {
        String ss = s.replaceAll(",", ";").replaceAll("\t", ", ").replaceAll("\"", "");
        System.out.println(ss);
        String fld[] = ss.split(",");
        String code = fld[0].trim();
        String sec = Utilities.cleanSecInd(fld[1]);
        System.out.println(sec);
        String ind = Utilities.cleanSecInd(fld[2]);
        System.out.println(ind);
        pw.printf("%s, %s, %s%n", code, sec, ind);
      }
    }
    catch (FileNotFoundException e) {
      e.printStackTrace();
    }

  }

  /**
   *
   * @param industry
   * @return
   */
  private static GroupData getIndustry(String industry) {
    for (final GroupData gd : WriteIndSecRs.industryList) {
      if (gd.groupName.equals(industry)) {
        return gd;
      }
    }
    return null;
  }

  /**
   *
   * @param sector
   * @return
   */
  private static GroupData getSector(String sector) {
    for (final GroupData gd : WriteIndSecRs.sectorList) {
      if (gd.groupName.equals(sector)) {
        return gd;
      }
    }
    return null;
  }

}
