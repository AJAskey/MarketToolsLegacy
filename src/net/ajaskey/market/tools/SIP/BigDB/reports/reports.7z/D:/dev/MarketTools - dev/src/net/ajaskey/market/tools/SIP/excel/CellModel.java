package net.ajaskey.market.tools.SIP.excel;

public class CellModel {

  public final static int NumberType = 2;
  public final static int StringType = 1;

  protected int    cellType;
  private int      column;
  private RowModel parent;
  private int      row;

}
