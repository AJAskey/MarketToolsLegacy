package net.ajaskey.market.tools.SIP;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.ajaskey.common.TextUtils;
import net.ajaskey.common.Utils;
import net.ajaskey.market.tools.SIP.BigDB.reports.utils.Utilities;

public class SipSectorIndustryRS {

  private static final double MAX_RS = 80.0;

  private static boolean doDebug = false;

  private final static List<Fields> fieldList    = new ArrayList<>();
  private static List<GroupData>    sectorList   = new ArrayList<>();
  private static List<GroupData>    industryList = new ArrayList<>();

  private static SipSectorIndustryRS ssirs = new SipSectorIndustryRS();

  /**
   *
   * @author Computer
   *
   */
  public class Fields {
    String code;
    String industry;
    double rs1;
    double rs12;
    double rs3;
    double rs6;
    String sector;
    double weightedRS;

    /**
     *
     * @param ss
     */
    public Fields(String ss) {
      final String fld[] = ss.split(",");
      this.code = fld[0].trim();
      this.sector = Utilities.cleanSecInd(fld[1]);
      this.industry = Utilities.cleanSecInd(fld[2]);

      double tmp = Utils.parseDouble(fld[3].trim());
      this.rs1 = Math.min(tmp, SipSectorIndustryRS.MAX_RS);
      tmp = Utils.parseDouble(fld[4].trim());
      this.rs3 = Math.min(tmp, SipSectorIndustryRS.MAX_RS);
      tmp = Utils.parseDouble(fld[5].trim());
      this.rs6 = Math.min(tmp, SipSectorIndustryRS.MAX_RS);
      tmp = Utils.parseDouble(fld[6].trim());
      this.rs12 = Math.min(tmp, SipSectorIndustryRS.MAX_RS);

      this.calcRS();
    }

    /**
     * One-third 12m + One-third 6m + 0.255 3m + 0.085 1m
     *
     */
    private void calcRS() {
      this.weightedRS = this.rs12 * 0.33 + this.rs6 * 0.33 + this.rs3 * 0.255 + this.rs1 * 0.085;
    }
  }

  /**
   *
   * @author Computer
   *
   */
  public class GroupData {

    String       groupName;
    double       groupRS;
    List<Fields> list = null;

    /**
     *
     * @param s
     */
    public GroupData(String s) {
      this.groupName = s;
      this.list = new ArrayList<>();
      this.groupRS = 0.0;
    }

    /**
     * Average all in the group
     */
    public void calcGroupRS() {
      if (this.list.size() > 0) {
        double grs = 0.0;
        for (final Fields f : this.list) {
          grs += f.weightedRS;
        }
        this.groupRS = grs / this.list.size();
      }
    }
  }

  /**
   *
   * @param industry
   * @return
   */
  private static GroupData getIndustry(String industry) {
    for (final GroupData gd : SipSectorIndustryRS.industryList) {
      // System.out.printf("%s : %s %n", industry, gd.groupName);
      if (gd.groupName.equals(industry)) {
        if (gd.groupRS == 0.0) {
          gd.calcGroupRS();
        }
        return gd;
      }
    }
    return null;
  }

  /**
   * 
   * @param industry
   * @return
   */
  public static double getIndustryRS(String industry) {

    double ret = 0.0;
    GroupData gd = getIndustry(industry);
    if (gd != null) {
      ret = gd.groupRS;
    }
    return ret;
  }

  /**
   *
   * @param sector
   * @return
   */
  private static GroupData getSector(String sector) {
    for (final GroupData gd : SipSectorIndustryRS.sectorList) {
      if (gd.groupName.equals(sector)) {
        return gd;
      }
    }
    return null;
  }

  /**
   * 
   * @param sector
   * @return
   */
  public static double getSectorRS(String sector) {

    double ret = 0.0;
    GroupData gd = getSector(sector);
    if (gd != null) {
      ret = gd.groupRS;
    }
    return ret;
  }

  /**
   * 
   * @param s
   */
  public SipSectorIndustryRS(String desc, boolean debug) {

    doDebug = debug;

    SipSectorIndustryRS.processSipSectorIndustryData();

    SipSectorIndustryRS.createLists();

    System.out.printf("%nSipSectorIndustryRS initialized : %s%n Sectors    : %3d%n Industries : %3d%n%n", desc, sectorList.size(),
        industryList.size());

  }

  private SipSectorIndustryRS() {

  }

  /**
   *
   * @param args
   */
  public static void main(String[] args) {

    SipSectorIndustryRS init = new SipSectorIndustryRS(" SipSectorIndustryRS ", true);

    GroupData gd = getIndustry("Semiconductors");

    if (gd != null) {
      System.out.printf("%n%n%s\t%.2f%n", gd.groupName, gd.groupRS);
    }

  }

  /**
   * Local lists
   */
  static List<String> usList = null;
  static List<String> uiList = null;

  /**
   * Creates.
   * 
   * A GroupData list for each individual sector.
   * 
   * A GroupData list for each individual industry.
   * 
   * Adds companies to lists from fieldLists
   */
  private static void createLists() {

    /**
     * Create a list of Sectors
     */
    Collections.sort(usList);
    for (final String s : usList) {
      final GroupData gd = SipSectorIndustryRS.ssirs.new GroupData(s);
      for (Fields f : fieldList) {
        if (f.sector.equals(s)) {
          gd.list.add(f);
        }
      }
      gd.calcGroupRS();
      SipSectorIndustryRS.sectorList.add(gd);
      if (doDebug) {
        System.out.printf("%s : %.2f :: %d%n", s, gd.groupRS, gd.list.size());
      }
    }

    System.out.printf("%n%n%n");

    /**
     * Create a list of Industries
     */
    Collections.sort(uiList);
    for (final String s : uiList) {
      final GroupData gd = SipSectorIndustryRS.ssirs.new GroupData(s);
      for (Fields f : fieldList) {
        if (f.industry.equals(s)) {
          gd.list.add(f);
        }
      }
      gd.calcGroupRS();
      SipSectorIndustryRS.industryList.add(gd);
      if (doDebug) {
        System.out.printf("%s : %.2f :: %d%n", s, gd.groupRS, gd.list.size());
      }
    }

    if (doDebug) {
      System.out.printf("%nSectors    : %d%n", SipSectorIndustryRS.sectorList.size());
      System.out.printf("Industries : %d%n", SipSectorIndustryRS.industryList.size());
    }
  }

  /**
   * Fills:
   * 
   * fieldList with contents of SIP data file.
   * 
   * usList with a set of individual sectors.
   * 
   * uiList with a set of individual industries.
   */
  private static void processSipSectorIndustryData() {

    Set<String> uniqSectors = new HashSet<>();
    Set<String> uniqIndustries = new HashSet<>();

    final List<String> data = TextUtils.readTextFile("input/CODESECTORINDUSTRY-SIP.TXT", true);

    try (PrintWriter pw = new PrintWriter("out/SipSectorIndustryRS.csv")) {
      for (final String s : data) {
        final String ss = s.replaceAll(",", ";").replaceAll("\t", ", ").replaceAll("\"", "");

        final Fields fld = SipSectorIndustryRS.ssirs.new Fields(ss);

        SipSectorIndustryRS.fieldList.add(fld);
        uniqSectors.add(fld.sector);
        uniqIndustries.add(fld.industry);

        pw.printf("%s, %s, %s, %.2f, %.2f, %.2f, %.2f, %.4f%n", fld.code, fld.sector, fld.industry, fld.rs1, fld.rs3, fld.rs6, fld.rs12,
            fld.weightedRS);

      }
    }
    catch (final FileNotFoundException e) {
      e.printStackTrace();
    }

    SipSectorIndustryRS.usList = new ArrayList<>(uniqSectors);
    SipSectorIndustryRS.uiList = new ArrayList<>(uniqIndustries);

  }

}
